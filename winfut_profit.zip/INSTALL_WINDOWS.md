# Instruções para Instalação do WINFUT Robot no Windows

## Pré-requisitos
- Python 3.8 ou superior
- Profit Pro 5.0.3 ou superior instalado e funcionando
- Windows 10 ou 11 (necessário para integração com a DLL)

## Passo 1: Descompactar os arquivos
1. Extraia o conteúdo do arquivo ZIP para uma pasta dedicada (ex: "C:/WINFUT_Robot")

## Passo 2: Criar ambiente virtual (recomendado)
1. Abra o Prompt de Comando como administrador
2. Navegue até a pasta do projeto: `cd C:/WINFUT_Robot`
3. Crie um ambiente virtual: `python -m venv venv`
4. Ative o ambiente: `venv\Scripts\activate`

## Passo 3: Instalar dependências
1. Com o ambiente virtual ativado, execute: `pip install -r requirements.txt`
2. Se encontrar problemas com ta-lib-easy, tente instalar ta-lib-bin: `pip install ta-lib-bin`

## Passo 4: Verificar o caminho da DLL
1. Abra o arquivo `config.py` em um editor de texto
2. Verifique se o caminho da DLL está correto para sua instalação:
   ```python
   PROFIT_PRO_DLL_PATH = os.getenv("PROFIT_PRO_DLL_PATH", "C:/Users/Razer Blade/AppData/Roaming/Nelogica/Profit/ProfitDLL/DLLs/Win64/ProfitDLL64.dll")
   ```
3. Se necessário, ajuste o caminho para corresponder à localização da DLL em seu sistema

## Passo 5: Iniciar o robô
1. Certifique-se de que o Profit Pro está aberto e logado
2. Com o ambiente virtual ativado, execute: `streamlit run app.py`
3. O robô abrirá no seu navegador em http://localhost:8501

## Observações importantes
- O robô inicia em modo de simulação por padrão (não envia ordens reais)
- A ativação da DLL é feita utilizando a chave já configurada
- Para operações reais, desative o "Modo de Simulação" na interface

## Solução de problemas
- Se encontrar erros relacionados à DLL, verifique no arquivo `profit_dll.log`
- Para erros gerais, consulte o arquivo `winfut_robot.log`
