from ctypes import *
from profitTypes import *
import platform
import os
import logging

# Configuração do logger
logger = logging.getLogger("profit_dll")
logger.setLevel(logging.INFO)
handler = logging.FileHandler("profit_dll.log")
handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
logger.addHandler(handler)

def initializeDll(path: str) -> CDLL:
    """
    Inicializa a biblioteca DLL do Profit Pro.
    
    Args:
        path: Caminho completo para o arquivo da DLL
        
    Returns:
        Objeto da DLL carregada
    """
    try:
        logger.info(f"Tentando carregar DLL do caminho: {path}")
        
        # Verifica se estamos no Windows (necessário para a DLL)
        if platform.system() != 'Windows':
            logger.error("Sistema não é Windows. A DLL do Profit Pro requer Windows.")
            raise RuntimeError("A DLL do Profit Pro requer ambiente Windows para funcionar.")
        
        # Verifica se o arquivo existe
        if not os.path.exists(path):
            logger.error(f"Arquivo DLL não encontrado: {path}")
            raise FileNotFoundError(f"Arquivo DLL não encontrado: {path}")
        
        # Carrega a DLL
        try:
            if '64' in path:
                # Versão de 64 bits
                profit_dll = CDLL(path)
                logger.info("DLL de 64 bits carregada com sucesso")
            else:
                # Versão de 32 bits
                profit_dll = CDLL(path)
                logger.info("DLL de 32 bits carregada com sucesso")
        except Exception as e:
            logger.error(f"Erro ao carregar DLL: {str(e)}")
            raise
        
        # Configuração dos tipos de retorno
        profit_dll.SendSellOrder.restype = c_longlong
        profit_dll.SendBuyOrder.restype = c_longlong
        profit_dll.SendZeroPosition.restype = c_longlong
        profit_dll.GetAgentNameByID.restype = c_wchar_p
        profit_dll.GetAgentShortNameByID.restype = c_wchar_p
        profit_dll.GetPosition.restype = POINTER(c_int)
        profit_dll.SendMarketSellOrder.restype = c_int64
        profit_dll.SendMarketBuyOrder.restype = c_int64

        # Configuração dos tipos de argumentos
        profit_dll.SendStopSellOrder.argtypes = [c_wchar_p, c_wchar_p, c_wchar_p, c_wchar_p, c_wchar_p, c_double, c_double, c_int]
        profit_dll.SendStopSellOrder.restype = c_longlong

        profit_dll.SendStopBuyOrder.argtypes = [c_wchar_p, c_wchar_p, c_wchar_p, c_wchar_p, c_wchar_p, c_double, c_double, c_int]
        profit_dll.SendStopBuyOrder.restype = c_longlong

        profit_dll.SendOrder.argtypes = [POINTER(TConnectorSendOrder)]
        profit_dll.SendOrder.restype = c_int64

        profit_dll.SendChangeOrderV2.argtypes = [POINTER(TConnectorChangeOrder)]
        profit_dll.SendChangeOrderV2.restype = c_int

        profit_dll.SendCancelOrderV2.argtypes = [POINTER(TConnectorCancelOrder)]
        profit_dll.SendCancelOrderV2.restype = c_int

        profit_dll.SendCancelOrdersV2.argtypes = [POINTER(TConnectorCancelOrders)]
        profit_dll.SendCancelOrdersV2.restype = c_int

        profit_dll.SendCancelAllOrdersV2.argtypes = [POINTER(TConnectorCancelAllOrders)]
        profit_dll.SendCancelAllOrdersV2.restype = c_int

        profit_dll.SendZeroPositionV2.argtypes = [POINTER(TConnectorZeroPosition)]
        profit_dll.SendZeroPositionV2.restype = c_int64

        profit_dll.GetAccountCount.argtypes = []
        profit_dll.GetAccountCount.restype = c_int

        profit_dll.GetAccounts.argtypes = [c_int, c_int, c_int, POINTER(TConnectorAccountIdentifierOut)]
        profit_dll.GetAccounts.restype = c_int

        profit_dll.GetAccountDetails.argtypes = [POINTER(TConnectorTradingAccountOut)]
        profit_dll.GetAccountDetails.restype = c_int

        profit_dll.GetSubAccountCount.argtypes = [POINTER(TConnectorAccountIdentifier)]
        profit_dll.GetSubAccountCount.restype = c_int

        profit_dll.GetSubAccounts.argtypes = [POINTER(TConnectorAccountIdentifier), c_int, c_int, c_int, POINTER(TConnectorAccountIdentifierOut)]
        profit_dll.GetSubAccounts.restype = c_int

        profit_dll.GetPositionV2.argtypes = [POINTER(TConnectorTradingAccountPosition)]
        profit_dll.GetPositionV2.restype = c_int

        profit_dll.GetOrderDetails.argtypes = [POINTER(TConnectorOrderOut)]
        profit_dll.GetOrderDetails.restype = c_int

        logger.info("Configuração de tipos de dados da DLL concluída com sucesso")
        return profit_dll

    except Exception as e:
        logger.critical(f"Erro crítico ao inicializar DLL: {str(e)}")
        # Em ambiente de produção, retornamos None e deixamos o chamador tratar o erro
        # Em ambiente de desenvolvimento, podemos permitir que a exceção seja propagada
        raise