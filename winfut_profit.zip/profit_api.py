"""
API para comunicação com o Profit Pro.

Este módulo atua como uma interface unificada para comunicação com o Profit Pro,
independente do método de comunicação (DLL ou socket), fornecendo uma API consistente
para o resto da aplicação.
"""

import os
import time
import logging
import platform
import threading
from typing import Dict, List, Tuple, Optional, Any, Union
from datetime import datetime

# Importações condicionais para suporte Windows/Linux
if platform.system() == 'Windows':
    from profit_dll_manager import ProfitDLLManager

# Configuração do logger
logger = logging.getLogger("profit_api")
logger.setLevel(logging.INFO)
handler = logging.FileHandler("winfut_robot.log")
handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
logger.addHandler(handler)

class ProfitAPI:
    """
    API para comunicação com o Profit Pro.
    
    Esta classe fornece uma interface unificada para comunicação com o Profit Pro,
    independente do método subjacente (DLL ou socket).
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa a API do Profit Pro.
        
        Args:
            config: Configurações para a API do Profit Pro
        """
        self.config = config
        self.manager = None
        self.is_windows = platform.system() == 'Windows'
        self.use_dll = config.get("PROFIT_PRO_USE_DLL", True)
        self.simulation_mode = config.get("PROFIT_PRO_SIMULATION_MODE", True)
        
        # Verificar ambiente e selecionar o método de comunicação apropriado
        if self.use_dll and self.is_windows:
            logger.info("Usando gerenciador de DLL para comunicação com o Profit Pro")
            self.manager = ProfitDLLManager(config)
        elif self.use_dll and not self.is_windows:
            logger.warning("DLL solicitada, mas ambiente não é Windows. Usando modo de simulação.")
            self.simulation_mode = True
            self.manager = self._create_simulation_manager()
        else:
            # Não é para usar DLL ou não estamos no Windows
            logger.info("Usando modo de simulação para operações de trading")
            self.simulation_mode = True
            self.manager = self._create_simulation_manager()
            
        # Status de prontidão
        self.is_initialized = False
            
    def _create_simulation_manager(self) -> Any:
        """
        Cria um gerenciador de simulação para ambientes que não podem usar a DLL.
        
        Returns:
            Objeto de gerenciador de simulação
        """
        # Criamos um objeto simulado que implementa os mesmos métodos que o ProfitDLLManager
        class SimulationManager:
            def __init__(self, parent):
                self.parent = parent
                self.is_initialized = False
                self.is_activated = False
                self.is_connected = False
                self.is_broker_connected = False
                self.is_market_connected = False
                self.simulation_mode = True
                
            def initialize(self) -> bool:
                logger.info("[SIMULAÇÃO] Inicializando gerenciador simulado")
                self.is_initialized = True
                return True
                
            def activate(self) -> bool:
                logger.info("[SIMULAÇÃO] Ativando gerenciador simulado")
                self.is_activated = True
                return True
                
            def connect(self, username: str = "", password: str = "") -> bool:
                logger.info("[SIMULAÇÃO] Conectando gerenciador simulado")
                self.is_connected = True
                self.is_broker_connected = True
                self.is_market_connected = True
                return True
                
            def disconnect(self) -> bool:
                logger.info("[SIMULAÇÃO] Desconectando gerenciador simulado")
                self.is_connected = False
                self.is_broker_connected = False
                self.is_market_connected = False
                return True
                
            def send_buy_order(self, ticker: str, exchange: str = "XBMF", price: float = 0.0, 
                              quantity: int = 1, account_id: str = "", broker_id: int = 0) -> Optional[int]:
                import random
                order_id = random.randint(10000, 99999)
                logger.info(f"[SIMULAÇÃO] Enviando ordem de COMPRA: {ticker} {quantity}x @ {price}")
                logger.info(f"[SIMULAÇÃO] Ordem de COMPRA enviada com ID: {order_id}")
                return order_id
                
            def send_sell_order(self, ticker: str, exchange: str = "XBMF", price: float = 0.0, 
                               quantity: int = 1, account_id: str = "", broker_id: int = 0) -> Optional[int]:
                import random
                order_id = random.randint(10000, 99999)
                logger.info(f"[SIMULAÇÃO] Enviando ordem de VENDA: {ticker} {quantity}x @ {price}")
                logger.info(f"[SIMULAÇÃO] Ordem de VENDA enviada com ID: {order_id}")
                return order_id
                
            def get_position(self, ticker: str, exchange: str = "XBMF", 
                            account_id: str = "", broker_id: int = 0) -> Dict[str, Any]:
                logger.info(f"[SIMULAÇÃO] Consultando posição para: {ticker}")
                return {
                    "asset": ticker,
                    "quantity": 0,  # Posição zerada na simulação
                    "average_price": 0.0,
                    "side": "flat",
                    "day_trade_quantity": 0,
                    "position_type": "day_trade"
                }
                
            def close_position(self, ticker: str, exchange: str = "XBMF", 
                              account_id: str = "", broker_id: int = 0) -> bool:
                logger.info(f"[SIMULAÇÃO] Zerando posição para: {ticker}")
                return True
                
            def cancel_order(self, order_id: int, account_id: str = "", broker_id: int = 0) -> bool:
                logger.info(f"[SIMULAÇÃO] Cancelando ordem: {order_id}")
                return True
                
            def cancel_all_orders(self, account_id: str = "", broker_id: int = 0) -> bool:
                logger.info(f"[SIMULAÇÃO] Cancelando todas as ordens")
                return True
                
            def get_accounts(self) -> List[Dict[str, Any]]:
                logger.info("[SIMULAÇÃO] Consultando contas disponíveis")
                return [{
                    "broker_id": 0,
                    "broker_name": "Corretora Simulada",
                    "account_id": "SIMU1234",
                    "owner_name": "Usuário de Simulação"
                }]
                
            def is_ready(self) -> bool:
                return self.is_initialized
                
            def get_status(self) -> Dict[str, Any]:
                return {
                    "initialized": self.is_initialized,
                    "activated": self.is_activated,
                    "connected": self.is_connected,
                    "broker_connected": self.is_broker_connected,
                    "market_connected": self.is_market_connected,
                    "simulation_mode": self.simulation_mode,
                    "ready": self.is_ready()
                }
                
        return SimulationManager(self)
            
    def initialize(self) -> bool:
        """
        Inicializa a API do Profit Pro.
        
        Returns:
            True se a inicialização foi bem-sucedida, False caso contrário
        """
        try:
            if self.manager:
                result = self.manager.initialize()
                if result:
                    logger.info("API do Profit Pro inicializada com sucesso")
                    self.is_initialized = True
                else:
                    logger.error("Falha ao inicializar API do Profit Pro")
                return result
            else:
                logger.error("Nenhum gerenciador disponível para inicialização")
                return False
        except Exception as e:
            logger.error(f"Erro ao inicializar API do Profit Pro: {str(e)}")
            return False
            
    def connect(self, username: str = "", password: str = "") -> bool:
        """
        Conecta ao Profit Pro.
        
        Args:
            username: Nome de usuário para login (opcional)
            password: Senha para login (opcional)
            
        Returns:
            True se a conexão foi bem-sucedida, False caso contrário
        """
        if not self.is_initialized:
            logger.error("Tentativa de conectar antes da inicialização")
            return False
            
        try:
            if self.manager:
                return self.manager.connect(username, password)
            else:
                logger.error("Nenhum gerenciador disponível para conexão")
                return False
        except Exception as e:
            logger.error(f"Erro ao conectar ao Profit Pro: {str(e)}")
            return False
            
    def disconnect(self) -> bool:
        """
        Desconecta do Profit Pro.
        
        Returns:
            True se a desconexão foi bem-sucedida, False caso contrário
        """
        if not self.is_initialized:
            logger.warning("Tentativa de desconectar antes da inicialização")
            return False
            
        try:
            if self.manager:
                return self.manager.disconnect()
            else:
                logger.error("Nenhum gerenciador disponível para desconexão")
                return False
        except Exception as e:
            logger.error(f"Erro ao desconectar do Profit Pro: {str(e)}")
            return False
            
    def send_buy_order(self, ticker: str, exchange: str = "XBMF", price: float = 0.0, 
                       quantity: int = 1, account_id: str = "", broker_id: int = 0) -> Optional[int]:
        """
        Envia uma ordem de compra para o ativo especificado.
        
        Args:
            ticker: Código do ativo (ex: "WINFUT")
            exchange: Código da bolsa (ex: "XBMF")
            price: Preço da ordem (0 para ordem a mercado)
            quantity: Quantidade a ser comprada
            account_id: ID da conta na corretora
            broker_id: ID da corretora
            
        Returns:
            ID da ordem se bem-sucedido, None caso contrário
        """
        if not self.is_initialized:
            logger.error("Tentativa de enviar ordem antes da inicialização")
            return None
            
        try:
            if self.manager:
                return self.manager.send_buy_order(ticker, exchange, price, quantity, account_id, broker_id)
            else:
                logger.error("Nenhum gerenciador disponível para envio de ordem")
                return None
        except Exception as e:
            logger.error(f"Erro ao enviar ordem de compra: {str(e)}")
            return None
            
    def send_sell_order(self, ticker: str, exchange: str = "XBMF", price: float = 0.0, 
                        quantity: int = 1, account_id: str = "", broker_id: int = 0) -> Optional[int]:
        """
        Envia uma ordem de venda para o ativo especificado.
        
        Args:
            ticker: Código do ativo (ex: "WINFUT")
            exchange: Código da bolsa (ex: "XBMF")
            price: Preço da ordem (0 para ordem a mercado)
            quantity: Quantidade a ser vendida
            account_id: ID da conta na corretora
            broker_id: ID da corretora
            
        Returns:
            ID da ordem se bem-sucedido, None caso contrário
        """
        if not self.is_initialized:
            logger.error("Tentativa de enviar ordem antes da inicialização")
            return None
            
        try:
            if self.manager:
                return self.manager.send_sell_order(ticker, exchange, price, quantity, account_id, broker_id)
            else:
                logger.error("Nenhum gerenciador disponível para envio de ordem")
                return None
        except Exception as e:
            logger.error(f"Erro ao enviar ordem de venda: {str(e)}")
            return None
            
    def get_position(self, ticker: str, exchange: str = "XBMF", 
                     account_id: str = "", broker_id: int = 0) -> Dict[str, Any]:
        """
        Obtém a posição atual para um ativo específico.
        
        Args:
            ticker: Código do ativo (ex: "WINFUT")
            exchange: Código da bolsa (ex: "XBMF")
            account_id: ID da conta na corretora
            broker_id: ID da corretora
            
        Returns:
            Dicionário com informações da posição
        """
        if not self.is_initialized:
            logger.error("Tentativa de obter posição antes da inicialização")
            return {"error": "Não inicializado"}
            
        try:
            if self.manager:
                return self.manager.get_position(ticker, exchange, account_id, broker_id)
            else:
                logger.error("Nenhum gerenciador disponível para consulta de posição")
                return {"error": "Nenhum gerenciador disponível"}
        except Exception as e:
            logger.error(f"Erro ao obter posição: {str(e)}")
            return {"error": f"Exceção: {str(e)}"}
            
    def close_position(self, ticker: str, exchange: str = "XBMF", 
                       account_id: str = "", broker_id: int = 0) -> bool:
        """
        Zera a posição para um ativo específico.
        
        Args:
            ticker: Código do ativo (ex: "WINFUT")
            exchange: Código da bolsa (ex: "XBMF")
            account_id: ID da conta na corretora
            broker_id: ID da corretora
            
        Returns:
            True se a posição foi zerada com sucesso, False caso contrário
        """
        if not self.is_initialized:
            logger.error("Tentativa de zerar posição antes da inicialização")
            return False
            
        try:
            if self.manager:
                return self.manager.close_position(ticker, exchange, account_id, broker_id)
            else:
                logger.error("Nenhum gerenciador disponível para zerar posição")
                return False
        except Exception as e:
            logger.error(f"Erro ao zerar posição: {str(e)}")
            return False
            
    def cancel_order(self, order_id: int, account_id: str = "", broker_id: int = 0) -> bool:
        """
        Cancela uma ordem específica.
        
        Args:
            order_id: ID da ordem a ser cancelada
            account_id: ID da conta na corretora
            broker_id: ID da corretora
            
        Returns:
            True se a ordem foi cancelada com sucesso, False caso contrário
        """
        if not self.is_initialized:
            logger.error("Tentativa de cancelar ordem antes da inicialização")
            return False
            
        try:
            if self.manager:
                return self.manager.cancel_order(order_id, account_id, broker_id)
            else:
                logger.error("Nenhum gerenciador disponível para cancelamento de ordem")
                return False
        except Exception as e:
            logger.error(f"Erro ao cancelar ordem: {str(e)}")
            return False
            
    def cancel_all_orders(self, account_id: str = "", broker_id: int = 0) -> bool:
        """
        Cancela todas as ordens ativas para uma conta.
        
        Args:
            account_id: ID da conta na corretora
            broker_id: ID da corretora
            
        Returns:
            True se as ordens foram canceladas com sucesso, False caso contrário
        """
        if not self.is_initialized:
            logger.error("Tentativa de cancelar todas as ordens antes da inicialização")
            return False
            
        try:
            if self.manager:
                return self.manager.cancel_all_orders(account_id, broker_id)
            else:
                logger.error("Nenhum gerenciador disponível para cancelamento de ordens")
                return False
        except Exception as e:
            logger.error(f"Erro ao cancelar todas as ordens: {str(e)}")
            return False
            
    def get_accounts(self) -> List[Dict[str, Any]]:
        """
        Obtém a lista de contas disponíveis.
        
        Returns:
            Lista de dicionários com informações das contas
        """
        if not self.is_initialized:
            logger.error("Tentativa de obter contas antes da inicialização")
            return []
            
        try:
            if self.manager:
                return self.manager.get_accounts()
            else:
                logger.error("Nenhum gerenciador disponível para consulta de contas")
                return []
        except Exception as e:
            logger.error(f"Erro ao obter contas: {str(e)}")
            return []
            
    def is_ready(self) -> bool:
        """
        Verifica se o sistema está pronto para operações de trading.
        
        Returns:
            True se o sistema está pronto, False caso contrário
        """
        if not self.is_initialized:
            return False
            
        try:
            if self.manager:
                return self.manager.is_ready()
            else:
                return False
        except Exception as e:
            logger.error(f"Erro ao verificar prontidão: {str(e)}")
            return False
            
    def get_status(self) -> Dict[str, Any]:
        """
        Obtém o status atual da conexão com o Profit Pro.
        
        Returns:
            Dicionário com informações de status
        """
        try:
            if self.manager:
                status = self.manager.get_status()
                status.update({
                    "api_initialized": self.is_initialized,
                    "api_simulation_mode": self.simulation_mode,
                    "api_use_dll": self.use_dll,
                    "api_is_windows": self.is_windows
                })
                return status
            else:
                return {
                    "error": "Nenhum gerenciador disponível",
                    "api_initialized": self.is_initialized,
                    "api_simulation_mode": self.simulation_mode,
                    "api_use_dll": self.use_dll,
                    "api_is_windows": self.is_windows
                }
        except Exception as e:
            logger.error(f"Erro ao obter status: {str(e)}")
            return {
                "error": f"Exceção: {str(e)}",
                "api_initialized": self.is_initialized,
                "api_simulation_mode": self.simulation_mode,
                "api_use_dll": self.use_dll,
                "api_is_windows": self.is_windows
            }
            
    def get_account_info(self) -> Dict[str, Any]:
        """
        Obtém informações da conta do usuário.
        
        Returns:
            Dicionário com informações da conta, incluindo saldo e lucros diários
        """
        try:
            if self.manager and hasattr(self.manager, "get_account_info"):
                return self.manager.get_account_info()
            else:
                # Fornecer dados simulados para compatibilidade
                logger.info("[SIMULAÇÃO] Retornando informações simuladas da conta")
                return {
                    "balance": 100000.0,  # Saldo simulado
                    "daily_pnl": 0.0,     # Lucro/prejuízo diário simulado
                    "equity": 100000.0,   # Patrimônio simulado
                    "margin": 0.0,        # Margem utilizada simulada
                    "free_margin": 100000.0,  # Margem livre simulada
                    "currency": "BRL",    # Moeda da conta
                    "leverage": 1.0,      # Alavancagem da conta
                    "account_id": "SIMULADO",  # ID da conta simulada
                    "broker": "Simulação"  # Nome da corretora
                }
        except Exception as e:
            logger.error(f"Erro ao obter informações da conta: {str(e)}")
            return {
                "balance": 100000.0,
                "daily_pnl": 0.0,
                "error": f"Exceção: {str(e)}"
            }