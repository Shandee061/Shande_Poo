"""
Gerenciador para comunicação com a DLL do Profit Pro.

Este módulo gerencia a interface entre o robô de trading e a API DLL do Profit Pro,
fornecendo métodos para conectar, autenticar, e executar operações de trading.
"""

import os
import sys
import time
import logging
import platform
from typing import Dict, List, Tuple, Optional, Any, Union
from datetime import datetime
from ctypes import byref, c_int, c_wchar_p, POINTER, c_double, c_int64

# Importações para a DLL do Profit Pro
from profitTypes import *
from profit_dll import initializeDll

# Configuração do logger
logger = logging.getLogger("profit_dll_manager")
logger.setLevel(logging.INFO)
handler = logging.FileHandler("winfut_robot.log")
handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
logger.addHandler(handler)

class ProfitDLLManager:
    """
    Gerenciador para comunicação com a DLL do Profit Pro.
    
    Esta classe gerencia o ciclo de vida da comunicação com a DLL do Profit Pro, incluindo:
    - Inicialização e carregamento da DLL
    - Autenticação com chave de ativação
    - Gerenciamento de conexão com a corretora
    - Execução de ordens de compra e venda
    - Monitoramento de posições e ordens
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o gerenciador da DLL do Profit Pro.
        
        Args:
            config: Configurações para a DLL do Profit Pro (caminhos, chaves, etc)
        """
        self.config = config
        self.profit_dll = None
        self.is_initialized = False
        self.is_connected = False
        self.is_broker_connected = False
        self.is_market_connected = False
        self.is_activated = False
        
        # Nome do arquivo DLL
        self.dll_path = self.config.get("PROFIT_PRO_DLL_PATH", "")
        self.activation_key = self.config.get("PROFIT_PRO_ACTIVATION_KEY", "")
        self.simulation_mode = self.config.get("PROFIT_PRO_SIMULATION_MODE", True)
        
        # Verificar ambiente Windows
        if platform.system() != 'Windows':
            logger.warning("Sistema não é Windows. A integração com DLL não funcionará.")
            self.is_windows = False
        else:
            self.is_windows = True
            
        logger.info(f"ProfitDLLManager inicializado. Simulation mode: {self.simulation_mode}")

    def initialize(self) -> bool:
        """
        Inicializa a comunicação com a DLL do Profit Pro.
        
        Returns:
            True se a inicialização foi bem-sucedida, False caso contrário
        """
        if not self.is_windows:
            logger.error("A inicialização da DLL do Profit Pro requer ambiente Windows.")
            return False
            
        if not self.dll_path:
            logger.error("Caminho da DLL não especificado na configuração.")
            return False
            
        try:
            logger.info(f"Inicializando DLL do Profit Pro: {self.dll_path}")
            self.profit_dll = initializeDll(self.dll_path)
            
            # Registrar callbacks
            self.register_callbacks()
            
            # Ativar a DLL com a chave de licença
            if self.activation_key:
                self.activate()
            else:
                logger.warning("Chave de ativação não fornecida. Algumas funcionalidades podem não estar disponíveis.")
            
            self.is_initialized = True
            logger.info("DLL do Profit Pro inicializada com sucesso.")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao inicializar DLL do Profit Pro: {str(e)}")
            return False
            
    def activate(self) -> bool:
        """
        Ativa a DLL do Profit Pro com a chave de licença.
        
        Returns:
            True se a ativação foi bem-sucedida, False caso contrário
        """
        if not self.is_initialized or not self.profit_dll:
            logger.error("Tentativa de ativar a DLL antes da inicialização.")
            return False
            
        try:
            logger.info("Ativando DLL do Profit Pro com a chave de licença...")
            # Converter a chave para o formato esperado pela DLL
            activate_result = self.profit_dll.Activate(c_wchar_p(self.activation_key))
            
            if activate_result == 0:  # Sucesso
                self.is_activated = True
                logger.info("DLL do Profit Pro ativada com sucesso.")
                return True
            else:
                logger.error(f"Falha ao ativar DLL do Profit Pro. Código de erro: {activate_result}")
                return False
                
        except Exception as e:
            logger.error(f"Erro ao ativar DLL do Profit Pro: {str(e)}")
            return False
    
    def register_callbacks(self) -> None:
        """
        Registra callbacks para eventos da DLL do Profit Pro.
        """
        if not self.is_initialized or not self.profit_dll:
            logger.error("Tentativa de registrar callbacks antes da inicialização.")
            return
            
        try:
            logger.info("Registrando callbacks para a DLL do Profit Pro...")
            
            # Callback de estado de conexão
            @CFUNCTYPE(None, c_int, c_int)
            def state_callback(n_type, n_result):
                if n_type == 0:  # Notificações de login
                    if n_result == 0:
                        self.is_connected = True
                        logger.info("Login conectado.")
                    else:
                        self.is_connected = False
                        logger.warning(f"Login não conectado: {n_result}")
                elif n_type == 1:  # Notificações da corretora
                    if n_result == 5:
                        self.is_broker_connected = True
                        logger.info("Corretora conectada.")
                    else:
                        self.is_broker_connected = False
                        logger.warning(f"Corretora não conectada: {n_result}")
                elif n_type == 2:  # Notificações do Market Data
                    if n_result == 4:
                        self.is_market_connected = True
                        logger.info("Market Data conectado.")
                    else:
                        self.is_market_connected = False
                        logger.warning(f"Market Data não conectado: {n_result}")
                elif n_type == 3:  # Notificações de ativação
                    if n_result == 0:
                        self.is_activated = True
                        logger.info("DLL ativada com sucesso.")
                    else:
                        self.is_activated = False
                        logger.warning(f"DLL não ativada: {n_result}")
            
            # Registrar o callback de estado
            self.profit_dll.SetStateCallback(state_callback)
            
            logger.info("Callbacks registrados com sucesso.")
            
        except Exception as e:
            logger.error(f"Erro ao registrar callbacks: {str(e)}")
            
    def connect(self, username: str = "", password: str = "") -> bool:
        """
        Conecta ao Profit Pro utilizando as credenciais fornecidas.
        
        Args:
            username: Nome de usuário para login (opcional)
            password: Senha para login (opcional)
            
        Returns:
            True se a conexão foi bem-sucedida, False caso contrário
        """
        if not self.is_initialized or not self.profit_dll:
            logger.error("Tentativa de conectar antes da inicialização.")
            return False
            
        try:
            # No modo de simulação, apenas fingimos que conectamos
            if self.simulation_mode:
                logger.info("Executando em modo de simulação. Simulando conexão bem-sucedida...")
                self.is_connected = True
                self.is_broker_connected = True
                self.is_market_connected = True
                return True
                
            # Conectar ao Profit Pro
            logger.info("Conectando ao Profit Pro...")
            
            # Se username/password fornecidos, use-os
            if username and password:
                connect_result = self.profit_dll.Connect(c_wchar_p(username), c_wchar_p(password))
            else:
                # Conecte sem credenciais (usa as salvas no Profit)
                connect_result = self.profit_dll.Connect(None, None)
                
            if connect_result == 0:  # Sucesso
                logger.info("Conectado ao Profit Pro com sucesso.")
                return True
            else:
                logger.error(f"Falha ao conectar ao Profit Pro. Código de erro: {connect_result}")
                return False
                
        except Exception as e:
            logger.error(f"Erro ao conectar ao Profit Pro: {str(e)}")
            return False
            
    def disconnect(self) -> bool:
        """
        Desconecta do Profit Pro.
        
        Returns:
            True se a desconexão foi bem-sucedida, False caso contrário
        """
        if not self.is_initialized or not self.profit_dll:
            logger.warning("Tentativa de desconectar antes da inicialização.")
            return False
            
        if not self.is_connected:
            logger.info("Já está desconectado.")
            return True
            
        try:
            # No modo de simulação, apenas atualizamos o estado
            if self.simulation_mode:
                logger.info("Executando em modo de simulação. Simulando desconexão...")
                self.is_connected = False
                self.is_broker_connected = False
                self.is_market_connected = False
                return True
                
            # Desconectar do Profit Pro
            logger.info("Desconectando do Profit Pro...")
            disconnect_result = self.profit_dll.Disconnect()
            
            if disconnect_result == 0:  # Sucesso
                self.is_connected = False
                self.is_broker_connected = False
                self.is_market_connected = False
                logger.info("Desconectado do Profit Pro com sucesso.")
                return True
            else:
                logger.error(f"Falha ao desconectar do Profit Pro. Código de erro: {disconnect_result}")
                return False
                
        except Exception as e:
            logger.error(f"Erro ao desconectar do Profit Pro: {str(e)}")
            return False
    
    def send_buy_order(self, ticker: str, exchange: str = "XBMF", price: float = 0.0, 
                        quantity: int = 1, account_id: str = "", broker_id: int = 0) -> Optional[int]:
        """
        Envia uma ordem de compra para o ativo especificado.
        
        Args:
            ticker: Código do ativo (ex: "WINFUT")
            exchange: Código da bolsa (ex: "XBMF")
            price: Preço da ordem (0 para ordem a mercado)
            quantity: Quantidade a ser comprada
            account_id: ID da conta na corretora
            broker_id: ID da corretora
            
        Returns:
            ID da ordem se bem-sucedido, None caso contrário
        """
        if not self.is_initialized or not self.profit_dll:
            logger.error("Tentativa de enviar ordem antes da inicialização.")
            return None
            
        # No modo de simulação, apenas simulamos a ordem
        if self.simulation_mode:
            logger.info(f"[SIMULAÇÃO] Enviando ordem de COMPRA: {ticker} {quantity}x @ {price}")
            # Gerar um ID de ordem simulado
            import random
            order_id = random.randint(10000, 99999)
            logger.info(f"[SIMULAÇÃO] Ordem de COMPRA enviada com ID: {order_id}")
            return order_id
            
        try:
            # Verificar se estamos conectados
            if not self.is_connected or not self.is_broker_connected:
                logger.error("Não conectado à corretora. Ordem de compra não enviada.")
                return None
                
            # Construir a ordem utilizando as estruturas da DLL
            order = TConnectorSendOrder(
                Version=0,
                AccountID=TConnectorAccountIdentifier(
                    Version=0,
                    BrokerID=broker_id,
                    AccountID=c_wchar_p(account_id) if account_id else None,
                    SubAccountID=None,
                    Reserved=0
                ),
                AssetID=TConnectorAssetIdentifier(
                    Version=0,
                    Ticker=c_wchar_p(ticker),
                    Exchange=c_wchar_p(exchange),
                    FeedType=0  # Feed type padrão
                ),
                Password=None,  # Senha não necessária para a maioria das operações
                OrderType=0 if price > 0 else 2,  # 0=Limit, 2=Market
                OrderSide=0,  # 0=Buy
                Price=c_double(price),
                StopPrice=c_double(0.0),  # Não é uma ordem stop
                Quantity=c_int64(quantity)
            )
            
            # Enviar a ordem
            logger.info(f"Enviando ordem de COMPRA: {ticker} {quantity}x @ {price}")
            order_id = self.profit_dll.SendOrder(byref(order))
            
            if order_id > 0:
                logger.info(f"Ordem de COMPRA enviada com ID: {order_id}")
                return order_id
            else:
                logger.error(f"Falha ao enviar ordem de COMPRA. Código de erro: {order_id}")
                return None
                
        except Exception as e:
            logger.error(f"Erro ao enviar ordem de COMPRA: {str(e)}")
            return None
    
    def send_sell_order(self, ticker: str, exchange: str = "XBMF", price: float = 0.0, 
                        quantity: int = 1, account_id: str = "", broker_id: int = 0) -> Optional[int]:
        """
        Envia uma ordem de venda para o ativo especificado.
        
        Args:
            ticker: Código do ativo (ex: "WINFUT")
            exchange: Código da bolsa (ex: "XBMF")
            price: Preço da ordem (0 para ordem a mercado)
            quantity: Quantidade a ser vendida
            account_id: ID da conta na corretora
            broker_id: ID da corretora
            
        Returns:
            ID da ordem se bem-sucedido, None caso contrário
        """
        if not self.is_initialized or not self.profit_dll:
            logger.error("Tentativa de enviar ordem antes da inicialização.")
            return None
            
        # No modo de simulação, apenas simulamos a ordem
        if self.simulation_mode:
            logger.info(f"[SIMULAÇÃO] Enviando ordem de VENDA: {ticker} {quantity}x @ {price}")
            # Gerar um ID de ordem simulado
            import random
            order_id = random.randint(10000, 99999)
            logger.info(f"[SIMULAÇÃO] Ordem de VENDA enviada com ID: {order_id}")
            return order_id
            
        try:
            # Verificar se estamos conectados
            if not self.is_connected or not self.is_broker_connected:
                logger.error("Não conectado à corretora. Ordem de venda não enviada.")
                return None
                
            # Construir a ordem utilizando as estruturas da DLL
            order = TConnectorSendOrder(
                Version=0,
                AccountID=TConnectorAccountIdentifier(
                    Version=0,
                    BrokerID=broker_id,
                    AccountID=c_wchar_p(account_id) if account_id else None,
                    SubAccountID=None,
                    Reserved=0
                ),
                AssetID=TConnectorAssetIdentifier(
                    Version=0,
                    Ticker=c_wchar_p(ticker),
                    Exchange=c_wchar_p(exchange),
                    FeedType=0  # Feed type padrão
                ),
                Password=None,  # Senha não necessária para a maioria das operações
                OrderType=0 if price > 0 else 2,  # 0=Limit, 2=Market
                OrderSide=1,  # 1=Sell
                Price=c_double(price),
                StopPrice=c_double(0.0),  # Não é uma ordem stop
                Quantity=c_int64(quantity)
            )
            
            # Enviar a ordem
            logger.info(f"Enviando ordem de VENDA: {ticker} {quantity}x @ {price}")
            order_id = self.profit_dll.SendOrder(byref(order))
            
            if order_id > 0:
                logger.info(f"Ordem de VENDA enviada com ID: {order_id}")
                return order_id
            else:
                logger.error(f"Falha ao enviar ordem de VENDA. Código de erro: {order_id}")
                return None
                
        except Exception as e:
            logger.error(f"Erro ao enviar ordem de VENDA: {str(e)}")
            return None
    
    def get_position(self, ticker: str, exchange: str = "XBMF", 
                      account_id: str = "", broker_id: int = 0) -> Dict[str, Any]:
        """
        Obtém a posição atual para um ativo específico.
        
        Args:
            ticker: Código do ativo (ex: "WINFUT")
            exchange: Código da bolsa (ex: "XBMF")
            account_id: ID da conta na corretora
            broker_id: ID da corretora
            
        Returns:
            Dicionário com informações da posição
        """
        if not self.is_initialized or not self.profit_dll:
            logger.error("Tentativa de obter posição antes da inicialização.")
            return {"error": "Não inicializado"}
            
        # No modo de simulação, retornamos valores simulados
        if self.simulation_mode:
            logger.info(f"[SIMULAÇÃO] Consultando posição para: {ticker}")
            return {
                "asset": ticker,
                "quantity": 0,  # Posição zerada na simulação
                "average_price": 0.0,
                "side": "flat",
                "day_trade_quantity": 0,
                "position_type": "day_trade"
            }
            
        try:
            # Verificar se estamos conectados
            if not self.is_connected or not self.is_broker_connected:
                logger.error("Não conectado à corretora. Não é possível obter posição.")
                return {"error": "Não conectado"}
                
            # Preparar a estrutura para consulta de posição
            position = TConnectorTradingAccountPosition(
                Version=0,
                AccountID=TConnectorAccountIdentifier(
                    Version=0,
                    BrokerID=broker_id,
                    AccountID=c_wchar_p(account_id) if account_id else None,
                    SubAccountID=None,
                    Reserved=0
                ),
                AssetID=TConnectorAssetIdentifier(
                    Version=0,
                    Ticker=c_wchar_p(ticker),
                    Exchange=c_wchar_p(exchange),
                    FeedType=0  # Feed type padrão
                ),
                PositionType=1  # 1=DayTrade
            )
            
            # Consultar a posição
            logger.info(f"Consultando posição para: {ticker}")
            result = self.profit_dll.GetPositionV2(byref(position))
            
            if result == 0:  # Sucesso
                side = "flat"
                if position.OpenQuantity > 0:
                    side = "buy" if position.OpenSide == 0 else "sell"
                    
                return {
                    "asset": ticker,
                    "quantity": abs(position.OpenQuantity),
                    "average_price": position.OpenAveragePrice,
                    "side": side,
                    "day_trade_quantity": position.DailyQuantity,
                    "position_type": "day_trade" if position.PositionType == 1 else "consolidated"
                }
            else:
                logger.warning(f"Falha ao consultar posição. Código de erro: {result}")
                return {"error": f"Erro ao consultar posição: {result}"}
                
        except Exception as e:
            logger.error(f"Erro ao consultar posição: {str(e)}")
            return {"error": f"Exceção: {str(e)}"}
    
    def close_position(self, ticker: str, exchange: str = "XBMF", 
                        account_id: str = "", broker_id: int = 0) -> bool:
        """
        Zera a posição para um ativo específico.
        
        Args:
            ticker: Código do ativo (ex: "WINFUT")
            exchange: Código da bolsa (ex: "XBMF")
            account_id: ID da conta na corretora
            broker_id: ID da corretora
            
        Returns:
            True se a posição foi zerada com sucesso, False caso contrário
        """
        if not self.is_initialized or not self.profit_dll:
            logger.error("Tentativa de zerar posição antes da inicialização.")
            return False
            
        # No modo de simulação, apenas simulamos o fechamento
        if self.simulation_mode:
            logger.info(f"[SIMULAÇÃO] Zerando posição para: {ticker}")
            return True
            
        try:
            # Verificar se estamos conectados
            if not self.is_connected or not self.is_broker_connected:
                logger.error("Não conectado à corretora. Não é possível zerar posição.")
                return False
                
            # Preparar a estrutura para zerar posição
            zero_position = TConnectorZeroPosition(
                Version=0,
                AccountID=TConnectorAccountIdentifier(
                    Version=0,
                    BrokerID=broker_id,
                    AccountID=c_wchar_p(account_id) if account_id else None,
                    SubAccountID=None,
                    Reserved=0
                ),
                AssetID=TConnectorAssetIdentifier(
                    Version=0,
                    Ticker=c_wchar_p(ticker),
                    Exchange=c_wchar_p(exchange),
                    FeedType=0  # Feed type padrão
                ),
                Password=None,  # Senha não necessária para a maioria das operações
                Price=c_double(0.0),  # 0.0 para ordem a mercado
                PositionType=1  # 1=DayTrade
            )
            
            # Zerar a posição
            logger.info(f"Zerando posição para: {ticker}")
            result = self.profit_dll.SendZeroPositionV2(byref(zero_position))
            
            if result > 0:  # ID da ordem > 0 significa sucesso
                logger.info(f"Posição zerada com sucesso para {ticker}. ID da ordem: {result}")
                return True
            else:
                logger.error(f"Falha ao zerar posição. Código de erro: {result}")
                return False
                
        except Exception as e:
            logger.error(f"Erro ao zerar posição: {str(e)}")
            return False
            
    def cancel_order(self, order_id: int, account_id: str = "", broker_id: int = 0) -> bool:
        """
        Cancela uma ordem específica.
        
        Args:
            order_id: ID da ordem a ser cancelada
            account_id: ID da conta na corretora
            broker_id: ID da corretora
            
        Returns:
            True se a ordem foi cancelada com sucesso, False caso contrário
        """
        if not self.is_initialized or not self.profit_dll:
            logger.error("Tentativa de cancelar ordem antes da inicialização.")
            return False
            
        # No modo de simulação, apenas simulamos o cancelamento
        if self.simulation_mode:
            logger.info(f"[SIMULAÇÃO] Cancelando ordem: {order_id}")
            return True
            
        try:
            # Verificar se estamos conectados
            if not self.is_connected or not self.is_broker_connected:
                logger.error("Não conectado à corretora. Não é possível cancelar ordem.")
                return False
                
            # Preparar a estrutura para cancelar ordem
            cancel_order = TConnectorCancelOrder(
                Version=0,
                AccountID=TConnectorAccountIdentifier(
                    Version=0,
                    BrokerID=broker_id,
                    AccountID=c_wchar_p(account_id) if account_id else None,
                    SubAccountID=None,
                    Reserved=0
                ),
                OrderID=TConnectorOrderIdentifier(
                    Version=0,
                    LocalOrderID=c_int64(order_id),
                    ClOrderID=None  # Cliente não fornece ClOrderID
                ),
                Password=None  # Senha não necessária para a maioria das operações
            )
            
            # Cancelar a ordem
            logger.info(f"Cancelando ordem: {order_id}")
            result = self.profit_dll.SendCancelOrderV2(byref(cancel_order))
            
            if result == 0:  # 0 = Success
                logger.info(f"Ordem {order_id} cancelada com sucesso")
                return True
            else:
                logger.error(f"Falha ao cancelar ordem {order_id}. Código de erro: {result}")
                return False
                
        except Exception as e:
            logger.error(f"Erro ao cancelar ordem: {str(e)}")
            return False
            
    def cancel_all_orders(self, account_id: str = "", broker_id: int = 0) -> bool:
        """
        Cancela todas as ordens ativas para uma conta.
        
        Args:
            account_id: ID da conta na corretora
            broker_id: ID da corretora
            
        Returns:
            True se as ordens foram canceladas com sucesso, False caso contrário
        """
        if not self.is_initialized or not self.profit_dll:
            logger.error("Tentativa de cancelar todas as ordens antes da inicialização.")
            return False
            
        # No modo de simulação, apenas simulamos o cancelamento
        if self.simulation_mode:
            logger.info(f"[SIMULAÇÃO] Cancelando todas as ordens")
            return True
            
        try:
            # Verificar se estamos conectados
            if not self.is_connected or not self.is_broker_connected:
                logger.error("Não conectado à corretora. Não é possível cancelar ordens.")
                return False
                
            # Preparar a estrutura para cancelar todas as ordens
            cancel_all = TConnectorCancelAllOrders(
                Version=0,
                AccountID=TConnectorAccountIdentifier(
                    Version=0,
                    BrokerID=broker_id,
                    AccountID=c_wchar_p(account_id) if account_id else None,
                    SubAccountID=None,
                    Reserved=0
                ),
                Password=None  # Senha não necessária para a maioria das operações
            )
            
            # Cancelar todas as ordens
            logger.info("Cancelando todas as ordens")
            result = self.profit_dll.SendCancelAllOrdersV2(byref(cancel_all))
            
            if result == 0:  # 0 = Success
                logger.info("Todas as ordens foram canceladas com sucesso")
                return True
            else:
                logger.error(f"Falha ao cancelar todas as ordens. Código de erro: {result}")
                return False
                
        except Exception as e:
            logger.error(f"Erro ao cancelar todas as ordens: {str(e)}")
            return False
    
    def get_accounts(self) -> List[Dict[str, Any]]:
        """
        Obtém a lista de contas disponíveis.
        
        Returns:
            Lista de dicionários com informações das contas
        """
        if not self.is_initialized or not self.profit_dll:
            logger.error("Tentativa de obter contas antes da inicialização.")
            return []
            
        # No modo de simulação, retornamos uma conta simulada
        if self.simulation_mode:
            logger.info("[SIMULAÇÃO] Consultando contas disponíveis")
            return [{
                "broker_id": 0,
                "broker_name": "Corretora Simulada",
                "account_id": "SIMU1234",
                "owner_name": "Usuário de Simulação"
            }]
            
        try:
            # Verificar se estamos conectados
            if not self.is_connected:
                logger.error("Não conectado. Não é possível obter contas.")
                return []
                
            # Obter o número de contas
            account_count = self.profit_dll.GetAccountCount()
            if account_count <= 0:
                logger.warning(f"Nenhuma conta encontrada. Retorno: {account_count}")
                return []
                
            logger.info(f"Encontradas {account_count} contas")
            
            # Preparar a estrutura para receber os dados
            accounts = []
            
            # Obter detalhes de cada conta
            for i in range(account_count):
                # Criar uma estrutura para receber os dados da conta
                account_data = TConnectorAccountIdentifierOut(
                    Version=0,
                    BrokerID=0,
                    AccountIDLength=100,
                    SubAccountIDLength=100
                )
                
                # Obter os dados da conta
                result = self.profit_dll.GetAccounts(i, 1, i, byref(account_data))
                
                if result == 0:  # 0 = Success
                    # Preparar para obter detalhes adicionais
                    account_details = TConnectorTradingAccountOut(
                        Version=0,
                        AccountID=TConnectorAccountIdentifier(
                            Version=0,
                            BrokerID=account_data.BrokerID,
                            AccountID=c_wchar_p(account_data.AccountID),
                            SubAccountID=c_wchar_p(account_data.SubAccountID) if account_data.SubAccountIDLength > 0 else None,
                            Reserved=0
                        ),
                        BrokerNameLength=100,
                        OwnerNameLength=100,
                        SubOwnerNameLength=100
                    )
                    
                    # Alocar memória para os campos de string
                    account_details.BrokerName = c_wchar_p(' ' * account_details.BrokerNameLength)
                    account_details.OwnerName = c_wchar_p(' ' * account_details.OwnerNameLength)
                    account_details.SubOwnerName = c_wchar_p(' ' * account_details.SubOwnerNameLength)
                    
                    # Obter detalhes da conta
                    details_result = self.profit_dll.GetAccountDetails(byref(account_details))
                    
                    if details_result == 0:  # 0 = Success
                        accounts.append({
                            "broker_id": account_data.BrokerID,
                            "broker_name": account_details.BrokerName.value,
                            "account_id": account_data.AccountID,
                            "owner_name": account_details.OwnerName.value
                        })
                    else:
                        logger.warning(f"Falha ao obter detalhes da conta {i}. Código de erro: {details_result}")
                else:
                    logger.warning(f"Falha ao obter informações da conta {i}. Código de erro: {result}")
            
            return accounts
                
        except Exception as e:
            logger.error(f"Erro ao obter contas: {str(e)}")
            return []
    
    def is_ready(self) -> bool:
        """
        Verifica se o sistema está pronto para operações de trading.
        
        Returns:
            True se o sistema está pronto, False caso contrário
        """
        # No modo de simulação, sempre consideramos pronto
        if self.simulation_mode:
            return self.is_initialized
            
        # No modo real, precisamos verificar todas as conexões
        return (self.is_initialized and self.is_activated and 
                self.is_connected and self.is_broker_connected)
                
    def get_status(self) -> Dict[str, Any]:
        """
        Obtém o status atual da conexão com o Profit Pro.
        
        Returns:
            Dicionário com informações de status
        """
        return {
            "initialized": self.is_initialized,
            "activated": self.is_activated,
            "connected": self.is_connected,
            "broker_connected": self.is_broker_connected,
            "market_connected": self.is_market_connected,
            "simulation_mode": self.simulation_mode,
            "ready": self.is_ready()
        }