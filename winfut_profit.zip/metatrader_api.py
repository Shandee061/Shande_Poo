"""
API para comunicação com o MetaTrader 5.

Este módulo foi mantido por compatibilidade, mas sua funcionalidade está desativada,
já que o robô agora usa exclusivamente a API do Profit Pro.
"""
import logging
from typing import Dict, List, Optional, Any, Union

# Configuração do logger
logger = logging.getLogger("metatrader_api")

class MetaTraderAPI:
    """
    API para comunicação com o MetaTrader 5.
    
    Esta classe foi mantida por compatibilidade, mas está desativada.
    O robô usa exclusivamente a API do Profit Pro.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa a API do MetaTrader 5.
        
        Args:
            config: Configurações para a API do MetaTrader 5
        """
        self.config = config
        self.enabled = False
        self.ready = False
        self.simulation_mode = True
        logger.warning("MetaTrader API está desativada. Usando exclusivamente Profit Pro.")
    
    def initialize(self) -> bool:
        """
        Inicializa a conexão com o MetaTrader 5.
        
        Returns:
            False (a API está desativada)
        """
        logger.info("Inicialização da API do MetaTrader ignorada (desativada)")
        return False
    
    def connect(self, username: str = "", password: str = "") -> bool:
        """
        Conecta ao MetaTrader 5.
        
        Args:
            username: Nome de usuário para login
            password: Senha para login
            
        Returns:
            False (a API está desativada)
        """
        logger.info("Conexão com MetaTrader ignorada (API desativada)")
        return False
    
    def disconnect(self) -> bool:
        """
        Desconecta do MetaTrader 5.
        
        Returns:
            True (a API está desativada)
        """
        return True
    
    def send_buy_order(self, symbol: str, volume: float = 1.0, price: float = 0.0) -> Optional[int]:
        """
        Envia uma ordem de compra (stub).
        
        Returns:
            None (a API está desativada)
        """
        logger.warning("Tentativa de enviar ordem de compra ignorada (API desativada)")
        return None
    
    def send_sell_order(self, symbol: str, volume: float = 1.0, price: float = 0.0) -> Optional[int]:
        """
        Envia uma ordem de venda (stub).
        
        Returns:
            None (a API está desativada)
        """
        logger.warning("Tentativa de enviar ordem de venda ignorada (API desativada)")
        return None
    
    def get_position(self, symbol: str) -> Dict[str, Any]:
        """
        Obtém a posição atual para um símbolo (stub).
        
        Returns:
            Dicionário vazio (a API está desativada)
        """
        return {
            "symbol": symbol,
            "volume": 0,
            "type": "none",
            "price_open": 0.0,
            "price_current": 0.0,
            "profit": 0.0
        }
    
    def close_position(self, symbol: str) -> bool:
        """
        Fecha a posição para um símbolo (stub).
        
        Returns:
            False (a API está desativada)
        """
        logger.warning("Tentativa de fechar posição ignorada (API desativada)")
        return False
    
    def cancel_order(self, order_id: int) -> bool:
        """
        Cancela uma ordem (stub).
        
        Returns:
            False (a API está desativada)
        """
        logger.warning("Tentativa de cancelar ordem ignorada (API desativada)")
        return False
    
    def cancel_all_orders(self) -> bool:
        """
        Cancela todas as ordens (stub).
        
        Returns:
            False (a API está desativada)
        """
        logger.warning("Tentativa de cancelar todas as ordens ignorada (API desativada)")
        return False
    
    def get_account_info(self) -> Dict[str, Any]:
        """
        Obtém as informações da conta (stub).
        
        Returns:
            Dicionário com valores zerados (a API está desativada)
        """
        return {
            "balance": 0.0,
            "equity": 0.0,
            "margin": 0.0,
            "free_margin": 0.0,
            "margin_level": 0.0,
            "leverage": 1
        }
    
    def is_ready(self) -> bool:
        """
        Verifica se a API está pronta para operações.
        
        Returns:
            False (a API está desativada)
        """
        return False