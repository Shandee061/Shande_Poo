# Instruções Simplificadas de Instalação do WINFUT Robot

## Pré-requisitos
- Python 3.8 ou superior
- Windows 10 ou 11
- Profit Pro 5.0.3 ou superior instalado

## Instalação Passo a Passo

### 1. Preparar o ambiente

1. Extraia o arquivo ZIP para uma pasta dedicada (ex: "C:/WINFUT_Robot")
2. Abra o Prompt de Comando como administrador
3. Navegue até a pasta do projeto:
   ```
   cd C:/WINFUT_Robot
   ```

### 2. Criar ambiente virtual

1. Crie um ambiente virtual:
   ```
   python -m venv venv
   ```
2. Ative o ambiente virtual:
   ```
   venv\Scripts\activate
   ```

### 3. Instalar dependências (MÉTODO SIMPLIFICADO)

Para evitar problemas com a compilação do ta-lib, use o seguinte método:

1. Instale as dependências principais:
   ```
   pip install streamlit pandas numpy matplotlib plotly scikit-learn joblib nltk textblob
   pip install newspaper3k beautifulsoup4 requests trafilatura seaborn xgboost
   ```

2. Use ta-lib-easy em vez de ta-lib (não requer compilação):
   ```
   pip install ta-lib-easy
   ```

3. Instale mplfinance:
   ```
   pip install mplfinance
   ```

### 4. Ajustar o caminho da DLL

1. Abra o arquivo `config.py` em um editor de texto
2. Localize a linha que contém o caminho da DLL:
   ```python
   PROFIT_PRO_DLL_PATH = os.getenv("PROFIT_PRO_DLL_PATH", "C:/Users/Razer Blade/AppData/Roaming/Nelogica/Profit/ProfitDLL/DLLs/Win64/ProfitDLL64.dll")
   ```
3. Altere o caminho para corresponder à localização da DLL em seu sistema
   * Verifique a localização da DLL no seu Profit Pro
   * Tipicamente está em: `C:/Users/SEU_USUARIO/AppData/Roaming/Nelogica/Profit/ProfitDLL/DLLs/Win64/ProfitDLL64.dll`

### 5. Testar a aplicação

1. Com o ambiente virtual ativado, execute:
   ```
   streamlit run app.py
   ```
2. A interface do robô deve abrir no seu navegador (http://localhost:8501)
3. O robô iniciará em modo de simulação (não envia ordens reais)

## Solução de Problemas

### Se a DLL não for encontrada:

Verifique o arquivo `profit_dll.log` para detalhes. O erro mais comum é o caminho incorreto para a DLL. Certifique-se de atualizar o caminho no `config.py`.

### Caso o Streamlit não inicie:

Certifique-se de que todas as dependências foram instaladas corretamente. Você pode tentar:
```
pip install -r requirements.txt
```

Se isso falhar para algum pacote específico, instale-os individualmente como mostrado acima.

### Se o ta-lib-easy não funcionar:

Uma alternativa é usar o ta-lib-bin:
```
pip install ta-lib-bin
```

### Se precisar das ferramentas de compilação:

Caso queira instalar o ta-lib original, primeiro instale o Microsoft C++ Build Tools:
https://visualstudio.microsoft.com/visual-cpp-build-tools/