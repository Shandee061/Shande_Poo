# Instalação do WINFUT Robot com Compilador C++

Esta versão das instruções de instalação destina-se a usuários que preferem instalar o ta-lib original (que requer compilação) usando o Microsoft Visual C++ Build Tools.

## 1. Instalar o Microsoft Visual C++ Build Tools

1. Baixe o instalador do Microsoft Visual C++ Build Tools:
   https://visualstudio.microsoft.com/visual-cpp-build-tools/

2. Execute o instalador e selecione:
   - Desenvolvimento para Desktop com C++
   - Ferramentas de build do C++ para Windows

3. Conclua a instalação (pode levar algum tempo)

## 2. Configurar ambiente Python

1. Extraia o arquivo ZIP do WINFUT Robot para uma pasta dedicada
2. Abra o Prompt de Comando como administrador
3. Navegue até a pasta do projeto: `cd C:/WINFUT_Robot`
4. Crie um ambiente virtual: `python -m venv venv`
5. Ative o ambiente: `venv\Scripts\activate`

## 3. Instalar TA-Lib

### 3.1 Instalar dependências gerais

```
pip install streamlit pandas numpy matplotlib plotly scikit-learn joblib
pip install nltk textblob newspaper3k beautifulsoup4 requests trafilatura
pip install mplfinance seaborn xgboost
```

### 3.2 Baixar e instalar o Wheel do TA-Lib

1. Baixe a versão pré-compilada (wheel) do TA-Lib para sua versão Python:
   https://www.lfd.uci.edu/~gohlke/pythonlibs/#ta-lib

2. Por exemplo, para Python 3.11 em Windows 64-bit, baixe:
   `TA_Lib‑0.4.27‑cp311‑cp311‑win_amd64.whl`

3. Instale o wheel baixado:
   ```
   pip install TA_Lib‑0.4.27‑cp311‑cp311‑win_amd64.whl
   ```

### 3.3 Ou instalar TA-Lib da fonte (se preferir)

Com o Visual C++ Build Tools instalado, você pode compilar o TA-Lib da fonte:

```
pip install ta-lib
```

## 4. Verificar o caminho da DLL do Profit Pro

1. Abra o arquivo `config.py` em um editor de texto
2. Localize o caminho da DLL:
   ```python
   PROFIT_PRO_DLL_PATH = os.getenv("PROFIT_PRO_DLL_PATH", "C:/Users/Razer Blade/AppData/Roaming/Nelogica/Profit/ProfitDLL/DLLs/Win64/ProfitDLL64.dll")
   ```
3. Atualize para o caminho correto em seu sistema

## 5. Executar o WINFUT Robot

1. Certifique-se de que o Profit Pro está aberto e logado
2. Ative o ambiente virtual: `venv\Scripts\activate`
3. Execute: `streamlit run app.py`

## Solução de problemas

Se você encontrar qualquer problema com a instalação de pacotes específicos:

### Usando pip verbose:
```
pip install -v ta-lib
```

### Verificando se o compilador está configurado corretamente:
```
python -c "import setuptools; setuptools._distutils.spawn._find_vcvarsall('x64')"
```
Este comando deve mostrar o caminho para o script vcvarsall.bat.