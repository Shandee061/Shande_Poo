# Soluções para Problemas Comuns de Instalação

Este documento contém soluções para problemas frequentemente encontrados durante a instalação do WINFUT Robot.

## Problema 1: Erro no NumPy (Error importing numpy)

**Erro:**
```
ImportError: Unable to import required dependencies: numpy: Error importing numpy: you should not try to import numpy from its source directory; please exit the numpy source tree, and relaunch your python interpreter from there.
```

**Soluções:**

### Solução 1: Criar um ambiente totalmente novo
1. Crie um diretório completamente novo: `mkdir C:\WINFUT_Robot_Novo`
2. Extraia o arquivo ZIP neste diretório limpo
3. Crie um ambiente virtual em outro local:
   ```
   python -m venv C:\venv_winfut
   C:\venv_winfut\Scripts\activate
   ```
4. Instale as dependências uma a uma:
   ```
   pip install numpy
   pip install pandas matplotlib plotly scikit-learn
   pip install streamlit
   pip install joblib nltk textblob newspaper3k beautifulsoup4 requests
   pip install trafilatura mplfinance seaborn xgboost
   pip install ta-lib-easy
   ```

### Solução 2: Usar Anaconda (recomendado)
1. Instale o Anaconda de [https://www.anaconda.com/download](https://www.anaconda.com/download)
2. Abra o Anaconda Prompt
3. Crie um ambiente: 
   ```
   conda create -n winfut_env python=3.11
   conda activate winfut_env
   ```
4. Instale as dependências:
   ```
   conda install numpy pandas matplotlib plotly scikit-learn
   conda install -c conda-forge streamlit
   conda install -c conda-forge ta-lib
   pip install joblib nltk textblob newspaper3k beautifulsoup4 requests trafilatura mplfinance seaborn xgboost
   ```
5. Execute: `streamlit run app.py`

### Solução 3: Limpar cache e versão específica
1. Limpe a cache do pip: `pip cache purge`
2. Reinstale o NumPy com versão específica:
   ```
   pip uninstall -y numpy
   pip install numpy==1.24.0
   ```

## Problema 2: Arquivo faltando (metatrader_api.py)

**Erro:**
```
ImportError: No module named 'metatrader_api'
```

ou

```
ModuleNotFoundError: No module named 'metatrader_api'
```

**Solução:**
O arquivo `metatrader_api.py` foi incluído no pacote ZIP mais recente.
Se estiver faltando, você pode baixar o pacote novamente ou criar o arquivo manualmente com o seguinte conteúdo:

```python
"""
API para comunicação com o MetaTrader 5.

Este módulo foi mantido por compatibilidade, mas sua funcionalidade está desativada,
já que o robô agora usa exclusivamente a API do Profit Pro.
"""
import logging
from typing import Dict, List, Optional, Any, Union

# Configuração do logger
logger = logging.getLogger("metatrader_api")

class MetaTraderAPI:
    """
    API para comunicação com o MetaTrader 5.
    
    Esta classe foi mantida por compatibilidade, mas está desativada.
    O robô usa exclusivamente a API do Profit Pro.
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.enabled = False
        self.ready = False
        self.simulation_mode = True
        logger.warning("MetaTrader API está desativada. Usando exclusivamente Profit Pro.")
    
    def initialize(self) -> bool:
        return False
    
    def connect(self, username: str = "", password: str = "") -> bool:
        return False
    
    def disconnect(self) -> bool:
        return True
    
    def send_buy_order(self, symbol: str, volume: float = 1.0, price: float = 0.0) -> Optional[int]:
        return None
    
    def send_sell_order(self, symbol: str, volume: float = 1.0, price: float = 0.0) -> Optional[int]:
        return None
    
    def get_position(self, symbol: str) -> Dict[str, Any]:
        return {"symbol": symbol, "volume": 0, "type": "none", "price_open": 0.0, "price_current": 0.0, "profit": 0.0}
    
    def close_position(self, symbol: str) -> bool:
        return False
    
    def cancel_order(self, order_id: int) -> bool:
        return False
    
    def cancel_all_orders(self) -> bool:
        return False
    
    def get_account_info(self) -> Dict[str, Any]:
        return {"balance": 0.0, "equity": 0.0, "margin": 0.0, "free_margin": 0.0, "margin_level": 0.0, "leverage": 1}
    
    def is_ready(self) -> bool:
        return False
```

## Problema 3: Erro com ta-lib

**Erro:**
```
error: Microsoft Visual C++ 14.0 or greater is required. Get it with "Microsoft C++ Build Tools"
```

**Soluções:**

### Solução 1: Usar ta-lib-easy
1. Desinstale ta-lib se já tiver tentado instalar: `pip uninstall ta-lib`
2. Instale ta-lib-easy: `pip install ta-lib-easy`
3. Se necessário, modifique os imports no código:
   - De: `import talib`
   - Para: `import talib_easy as talib`

### Solução 2: Usar ta-lib-bin
1. Desinstale ta-lib se já tiver tentado instalar: `pip uninstall ta-lib`
2. Instale ta-lib-bin: `pip install ta-lib-bin`

### Solução 3: Usar wheel pré-compilado
1. Baixe o wheel apropriado de: https://www.lfd.uci.edu/~gohlke/pythonlibs/#ta-lib
2. Instale o wheel: `pip install TA_Lib‑0.4.27‑cp311‑cp311‑win_amd64.whl`

## Problema 4: ImportError para outros módulos

**Solução Geral:**
1. Instale as dependências uma a uma para identificar qual está causando o problema:
   ```
   pip install streamlit
   pip install pandas
   pip install numpy
   # ... e assim por diante
   ```

2. Para cada erro de importação de um módulo específico, instale-o:
   ```
   pip install <nome_do_modulo_faltante>
   ```

## Problema 5: Erro ao conectar com o Profit Pro

**Soluções:**
1. Verifique se o Profit Pro está aberto e logado
2. Verifique o caminho da DLL no arquivo `config.py`
3. Confirme que a versão do Profit Pro é 5.0.3 ou superior
4. Verifique o arquivo `profit_dll.log` para detalhes do erro